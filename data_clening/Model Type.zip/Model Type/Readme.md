# 🚀 Mobile App Feature Classifier

![License](https://img.shields.io/github/license/YOUR_USERNAME/YOUR_REPO_NAME?style=flat-square)
![Python Version](https://img.shields.io/badge/Python-3.8%2B-blue?style=flat-square&logo=python)
![Jupyter Notebook](https://img.shields.io/badge/Jupyter-Notebook-orange?style=flat-square&logo=jupyter)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-green?style=flat-square&logo=scikit-learn)
![Status](https://img.shields.io/badge/Status-Completed-success?style=flat-square)

---

## 📋 Table of Contents

* [Introduction](#-introduction)
* [Features](#-features)
* [Dataset](#-dataset)
* [Target Column Assumption](#-target-column-assumption)
* [Machine Learning Models Used](#-machine-learning-models-used)
* [Evaluation Metrics](#-evaluation-metrics)
* [Getting Started](#-getting-started)
    * [Prerequisites](#prerequisites)
    * [Cloning the Repository](#cloning-the-repository)
    * [Installation](#installation)
    * [Running the Notebook](#running-the-notebook)
* [Project Structure](#-project-structure)
* [Results & Analysis](#-results--analysis)
* [Contributing](#-contributing)
* [License](#-license)
* [Contact](#-contact)

---

## 🌟 Introduction

This repository hosts a supervised machine learning project aimed at classifying mobile applications based on their features, primarily permissions and intents. The goal is to build, evaluate, and compare various classification models to identify the most effective algorithm for distinguishing between different app categories or states (e.g., benign vs. malicious, specific app types).

This project provides a comprehensive pipeline, from data loading and preprocessing to model training, evaluation, and visualization of results, all implemented within a Jupyter Notebook environment.

---

## ✨ Features

* **Data Loading & Preprocessing:** Handles loading of `final_features.csv`, separating features and the target variable, and preparing data for modeling.
* **Feature Scaling:** Applies `StandardScaler` to normalize feature values, beneficial for distance-based algorithms.
* **Exploratory Data Analysis (EDA):** Visualizes the distribution of the target variable to check for class imbalance.
* **Multiple Supervised ML Models:** Implements and trains a diverse set of classification algorithms:
    * Logistic Regression
    * Decision Tree Classifier
    * Random Forest Classifier
    * Support Vector Machine (SVC)
    * K-Nearest Neighbors (KNN)
    * LightGBM Classifier (Gradient Boosting)
    * Bernoulli Naive Bayes
* **Robust Evaluation:** Utilizes `train_test_split` with stratification for reliable model evaluation.
* **Comprehensive Metric Reporting:** Calculates and displays Accuracy, Precision, Recall, F1-Score, and ROC AUC for each model.
* **Visualizations:**
    * Bar plots comparing model performance across various metrics.
    * Heatmaps of Confusion Matrices for each model.
    * ROC Curves for binary classification tasks to assess classifier performance.

---

## 📊 Dataset

The project uses a dataset named `final_features.csv`.
It is expected to contain the following structure:

* `app_name`: A unique identifier for each mobile application.
* Numerous feature columns (e.g., `P_ACCESS_ASSISTED_GPS`, `I_WALLPAPERSERVICE`): These are binary (0 or 1) indicators representing the presence or absence of specific permissions or intents in the application.
* A **target column**: This column contains the labels (classes) that the machine learning models will learn to predict.

---

## 🎯 Target Column Assumption

```python
target_column_name = 'class'